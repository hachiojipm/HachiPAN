# NAME

Yancha::Bot2 - おい、こっちのほうがいいぞ！

# SYNOPSIS

    use Yancha::Bot2;

# DESCRIPTION

Yancha::Bot2 is ...

# LICENSE

Copyright (C) moznion.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

moznion <moznion@gmail.com>
